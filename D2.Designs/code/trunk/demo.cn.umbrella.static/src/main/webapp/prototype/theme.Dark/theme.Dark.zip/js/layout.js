;;
//头部用户信息下拉
//var $parent = $(".fi-arrow-down").parent('a');
//下拉显示
function slideShow(){
	$('.user-control').css({
		'top':$(".fi-arrow-down").parent('a').offset().top + 10 + $(".fi-arrow-down").parent('a').outerHeight(),
		'left':$(".fi-arrow-down").parent('a').offset().left + 30 + 'px'
	}).slideDown().show();
};
//下拉隐藏
function slideHide(){
	$('.user-control').fadeOut("fast");
};

//home page中icon的行高
function homeIcon(){
	$(".home .main i").css({
		'line-height':$(".home .main i").parent('span').height() + 'px'
	});
};

//查询条件label的行高变化
function lineHeight(){
	$("label.query-label").each(function(){
		if($(this).height() > 30){
			$(this).css("lineHeight",1.3);
		};
	});
};

//iframe自适应
function iFrameHeight(id) {   
	var vHeight = $("#" + id).contents().find("body > div").height();
	$("#" + id).height(vHeight);
	$("#" + id).attr("width","100%");
};

var posTop;

function boxTop(obj){
	//在窗口变化后对main-table-outer不同上一级的移动位置
	if(obj == ('.tree-and-table-inner')){
		posTop = $(obj).prev('*').position().top + $(obj).prev('*').height() + 12;
	}else{
		if($(obj).prev('div').is('.main-control')){
			posTop = $('.main-control').offset().top;
		}else if($(obj).prev('div').is('.main-search')){
			if($(obj).hasClass('dialog-table-outer')){
				posTop = $('.main-search').offset().top + $('.main-search').height() + 5;
			}else{
				posTop = $('.main-search').offset().top;
			};
		}else if($(obj).prev('div').is('.main-bread-crumb')){
			posTop = $('.main-bread-crumb').height() + 4;
		}else if($(obj).prev('*').is('form')){
			posTop = $(obj).prev('form').height() ;
		};
	}
	$(obj).css({'margin-top' : posTop});
};
//marginTop
function marginTop(){
	boxTop('.main-table-outer');
	//tab里的top
	$('.tab-table-inner').each(function(){
		var $this = $(this);
		if($this.attr('class') != 'tab-table-inner tab-form'){
			var _innerParent = $this.parent('.tab-content');
			var _innerSiblings = _innerParent.children().length;
			switch (_innerSiblings) 
				{ 
					case 1:
						$this.css({
							'top':$this.parents('.tab-title-box').height() + 5
						});
					break; 
					case 2:
						$this.css({
							'top':function(){
								if($this.siblings().is('.main-control')){
									var paddingTop = $this.siblings('.main-control').css("padding-top"),
										paddingBottom = $this.siblings('.main-control').css("padding-bottom"),
										topLen = paddingTop.length,
										bottomLen = paddingBottom.length,
										num = Number(paddingTop.substring(0,topLen - 2)) +Number(paddingBottom.substring(0,topLen - 2));
									return $this.siblings().position().top + $this.siblings().height() + num;
								}else{
									return $this.siblings().position().top + $this.siblings().height();
								}
								
							}
						});
					break; 
					case 3:
						$this.css({
							'top':$this.siblings('.main-control').height() + $this.siblings('form').height() + 43
						});
					break; 
				};
		}
		
	});
};

$(function(){
	//侧边栏滚动条
	if($('.scroll').length > 0){
		$('.scroll').slimscroll({
			height:'100%'
	    });
	};
	
	//查询条件label的行高变化
	lineHeight();
	
	/*搜索栏下拉隐藏*/
	$(".hide-li").hide();
	
	//top位置变化
	marginTop();
	if($(".have-search .tree-and-table-inner").length > 0){
		boxTop('.tree-and-table-inner');
	};
	
	//dataGrid上方有form
	if($('.main-table-outer').find('.mini-form').length > 0){
		var dataGridTop = $('.mini-form').height() + 40;
	};
	$('.tree-and-table-inner').css({'top' : dataGridTop});
	
	/*高级搜索按钮点击*/
	$(".more-text").click(function() {
		$(this).parents("ul").children("li:first-child").toggleClass("w-per100");
		
		//清空值
		var idS = $('.main-search').closest('form').attr('id');
		document.getElementById(idS).reset(); 
		if($('.main-search').find(".been-elected-box").length > 0){
			$(".been-elected-box li").remove();
		};
		
		//高级搜索显示与隐藏
		if ($(this).prev(".hide-li").is(':visible')) {
			$(this).prev(".hide-li").hide();
			$(this).removeClass('up');
			
			//显示更多查询条件
			$(this).css({
				'border-top': '0 none'
			}).html('<p>显示更多查询条件<span class="fi-arrow-down"></span></p>');
			
			$(this).prev(".hide-li").find('.search-btn-group').width('auto').hide();
			
			//弹窗内两种搜索都有
			if($(this).parent('.main-search').prev('.dialog-search').length){
				$(this).parent('.main-search').prev('.dialog-search').show();
			};
			
			//查询条件label的行高变化
			lineHeight();
			
			//top位置变化
			marginTop();
			if($(".have-search .tree-and-table-inner").length > 0){
				boxTop('.tree-and-table-inner');
			};
			
			$('.user-datagrid').datagrid('resize', {
				height:'100%',
				width:'100%'
			});
			
		} else {
			$(this).prev(".hide-li").show();
			$(this).addClass('up');
			
			//隐藏更多查询条件
			$(this).css({
				'border-top': '1px dashed #e8e8e8'
			}).html('<p>隐藏查询条件<span class="fi-arrow-up"></span></p>');
			
			$(this).prev(".hide-li").find('.search-btn-group').width('100%').show();
			
			//弹窗内两种搜索都有
			if($(this).parent('.main-search').prev('.dialog-search').length){
				$(this).parent('.main-search').prev('.dialog-search').hide();
			};
			
			//查询条件label的行高变化
			lineHeight();
			
			//top位置变化
			marginTop();
			if($(".have-search .tree-and-table-inner").length > 0){
				boxTop('.tree-and-table-inner');
			};
			
			$('.user-datagrid').datagrid('resize', {
				height:'100%',
				width:'100%'
			});
		}
	});
	
	//针对tab页面,点击tab标签后dataGrid的自适应
	$('.tab-title-box > div').click(function(){
		$('.user-datagrid').datagrid('resize', {
			height:'100%',
			width:'100%'
		});
		
		//top位置变化
		marginTop();
	})
	
	//sub-nav控制————有三级菜单
	$('.cur').next('ul').slideDown(500).show();
	$('h3.cur').append('<span class="border-down-arrow"></span>');
	$('.sub-nav-inner > div > h3').click(function(){
		$(this).siblings('h3').removeClass('cur');
		$(this).siblings('h4').removeClass('cur');
		$(this).addClass('cur');
		$('.sub-nav-inner ul').hide();
		$('.cur').next('ul').slideDown(500).show();
		$('.cur').next('ul').children('li').eq(0).children('a').addClass('cur-a');
		location.href = $('.cur').next('ul').children('li').eq(0).find('a').attr('href');
		//控制菜单箭头
		$('h3.cur').append('<span class="border-down-arrow"></span>');
		$('h3.cur').remove('.border-down-arrow');
	});
	
	//sub-nav控制————无三级菜单
	$('.sub-nav-inner > div > h4').click(function(){
		$(this).siblings('h3').removeClass('cur');
		$(this).siblings('h4').removeClass('cur');
		$(this).addClass('cur');
		$('.sub-nav-inner ul').slideUp(500);
		location.href = $(this).find('a').attr('href');
		//控制菜单箭头
		$('.cur').siblings('h3').children('span').removeClass('fi-arrow-down').addClass('fi-arrow-right');
	});
	
	//sub-nav下h4里没有图标的情况下
	if($('.sub-nav-inner h4 a').find('i').length  > 0){
		$('.sub-nav-inner i').parents('h4').css({'padding-left':'60px'});
	};
	//当sub-nav里h4的行数大于1时调整行高
	$('.sub-nav-inner h4 a').each(function(){
		if($(this).text().length > 8){
			$(this).css('lineHeight',1.5);
			$(this).children('i').css('lineHeight',$(this).parent('h4').height() + 'px');
		};
	});
	
	//侧边栏缩进
	$('.fi-menu').click(function(){
		if ($('.sub-nav-outer').is(':visible')) {
			$('.sub-nav-outer').fadeOut('slow').hide();
			$('.main,.main-form-outer,.main-table-outer,.btn-row.fixed').css({'padding-left':0});
			$('.user-datagrid').datagrid('resize', {
				height:'100%',
				width:'100%'
			});
			$('.fi-menu').css({
				'left':'10px'
			});
			$(".main-bread-crumb,.tab-title-box").css("margin-left",0);
			$(".logo").css({
				'left':'48px'
			});
			$(".tab-table-inner").css("left","10px");
		} else{
			$('.sub-nav-outer').fadeOut('slow').show();
			$('.main,.main-form-outer,.main-table-outer,.btn-row.fixed').css({'padding-left':'200px'});
			$('.user-datagrid').datagrid('resize', {
				height:'100%',
				width:'100%'
			});
			$('.fi-menu').css({
				'left':'150px'
			});
			$(".logo").css({
				'left':'10px'
			});
			$(".tab-table-inner").css("left","210px");
		};
		$('.user-datagrid').datagrid('resize', {
			height:'100%',
			width:'100%'
		});
	});
	
	//头部用户信息下拉
	$('.top-info .fi-arrow-down').parent('a').click(function(){
		slideShow();
	});
	$('.user-control').mouseleave(function() {
		slideHide();
	});
	$("body").bind("click",function(evt){ 
		if($(evt.target).parents(".top-info").length==0) slideHide();
	});
	
	//斑马线
	$(".table-default tbody tr:even td").css({
		"backgroundColor": "#f5f5f5",
		"background": "none\9"
	});
	$(".table-default tbody tr:odd td").css({
		"backgroundColor": "#fff",
		"background": "none\9"
	});
	//home page中icon的行高
	homeIcon();
	
	//btn-row fixed滚动条控制
	if ($('.main-form-outer .btn-row.fixed').length <= 0) {
		$('.main-form-outer').css({'paddingBottom':'0'});
	};
	
	//在上传按钮上添加一个按钮
    /*$(".uploadify-button").prepend('<i class="fi fi-upload"></i>')*/
});

$(window).resize(function(){
	//top位置变化
	marginTop();
	if($(".have-search .tree-and-table-inner").length > 0){
		boxTop('.tree-and-table-inner');
	};
	//头部用户信息下拉
	slideHide();
	//home page中icon的行高
	homeIcon();
})